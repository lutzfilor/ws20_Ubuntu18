package PPCOV::JSON;
#----------------------------------------------------------------------------
# P A C K A G E - H E A D E R
#
# File          lib/PPCOV/JSON.pm
#
# Created       02/04/2019          
# Author        Lutz Filor
# 
# Synopsys      PPCOV::JSON::read_JSON()
#                       input   col Instance from Coverage Specification tab
#                       return  list of design instances
#
# Data model    [workbook]->@[sheet]->@name,[data]->@[col]->@cell
#                                          
#               
#----------------------------------------------------------------------------
#  I M P O R T S 
use strict;
use warnings;
use JSON;

use lib             qw  (   ../lib );               # Relative UserModulePath
use Dbg             qw  (   debug subroutine    );
use UTF8            qw  (   read_utf8   );

#----------------------------------------------------------------------------
#  I N T E R F A C E

use version; our $VERSION =version->declare("v1.01.01");

use Exporter qw (import);                           # Import <import>method  
use parent 'Exporter';                              # parent replaces base

our @EXPORT     =   qw  (    
                        );#implicite export         # NOT recommended 

our @EXPORT_OK  =   qw  (   _load_json   
                        );#explicite export         # RECOMMENDED method

our %EXPORT_TAGS=       ( ALL => [ @EXPORT_OK ],    # 
                        );

#----------------------------------------------------------------------------
#  C O N S T A N T S

#----------------------------------------------------------------------------
#  C O N S T R U C T O R

sub     new {
        my  $class  =   shift;
        my  ( $env  )   = @_;
        
        my $self   =   {};   
        $self   =  {   env =>  $env,   }; 
        bless   $self,  $class;
        #   $self->_initialize();
        
        return  $self;
}#sub   new constructor
#----------------------------------------------------------------------------
#  S U B R O U T I N S

sub     _load_json  {
        my  $self   =   shift;
        my  $file;
        my $json    =   read_utf8   ( $file );
}#sub   _load_json

sub     get_record  {
        my  $self   =   shift;
        my  $file   =   shift;
        my  $znumber=   shift;
        
}#sub   get_record




#----------------------------------------------------------------------------
# End of module
1;
