package PPCOV::Datapath;
#----------------------------------------------------------------------------
# P A C K A G E - H E A D E R
#
# File          lib/PPCOV/Datapath.pm
#
# Created       01/31/2019          
# Author        Lutz Filor
# 
# Synopsys      PPCOV::Datapath::process_instances()
#                       input   col Instance from Coverage Specification tab
#                       return  list of design instances
#
#               PPCOV::Datapath::get_zdata();
#                       input   zrecord Reference to the target instance
#                               scope   String with name of scope
#                       return  array   Reference to sample data
#----------------------------------------------------------------------------
#  I M P O R T S 

use strict;
use warnings;

use Readonly;

use lib             qw  (   ../lib );               # Relative UserModulePath
use Dbg             qw  (   debug subroutine    );
use UTF8            qw  (   read_utf8   );

#----------------------------------------------------------------------------
#  I N T E R F A C E

use version; our $VERSION =version->declare("v1.01.02");

use Exporter qw (import);                           # Import <import>method  
use parent 'Exporter';                              # parent replaces base

our @EXPORT     =   qw  (    
                        );#implicite export         # NOT recommended 

our @EXPORT_OK  =   qw  (   process_instances
                            get_references
                            get_attribute
                            get_filepath
                            get_record
                            get_zdata
                        );#explicite export         # RECOMMENDED method

our %EXPORT_TAGS=       ( ALL => [ @EXPORT_OK ],    # 
                        );

#----------------------------------------------------------------------------
#  C O N S T A N T S
Readonly my $TRUE           =>     1;               # Create boolean like constant
Readonly my $FALSE          =>     0;

#----------------------------------------------------------------------------
#  S U B R O U T I N S  -  P U B L I C  M E T H O D E S

sub     process_instances   {
        my  (   $blk_r
            ,   $inst_r     )   = @_;               # instance reference
        my $inst = [];                              # reference to instances
        my $n =  subroutine('name');                # identify sub by name
        if( debug($n))  {
            printf  "\n%5s%s() \n",'',$n;
            printf  "%10s%s %s\n",'','Size of Block', $#{$blk_r};
            printf  "%10s%s %s\n",'','Size of Block', $#{$inst_r}+1;
        }#if debug
        if ( $#{$blk_r} == $#{$inst_r}  )   {
            my $range  = $#{$blk_r}-1;
            my $col1   = maxwidth ( $blk_r  );
            my $col2   = maxwidth ( $inst_r );
            for my $i ( 1 .. $range ) {
                printf "%10s%*s | %*s\n",'',$col1,${$blk_r}[$i],$col2,${$inst_r}[$i];
                my @tmp = split / /, ${$inst_r}[$i];
                foreach my $e  ( @tmp ) {
                    push ( @{$inst}, $e ) if ($e !~ m/[+-]/ );
                }#
            }# for all blocks of interest
        } else {
            printf "\nWarning :: Block and Instance data are not complete !!\n";
        }
        my $u_inst = unique ( $inst );
        printf "\n" if(debug($n));
        return $u_inst;
}#sub   process_instances


sub     get_references  {
        my  (   $inst_r
            ,   $html_r     )   =   @_;
        my $n =  subroutine('name');                # identify sub by name
        my $href = [];
        if( debug($n))  {
            printf  "\n%5s%s() \n",'',$n;
            printf  "%10s%s %s\n",'','Size of index.html  ',$#{$html_r}+1;
            printf  "%10s%s %s\n",'','Number of instances ',$#{$inst_r}+1;
        }#
        my @tmp =  @{$html_r};
        my $ix  =   0;
        foreach my $line    ( @{$html_r} ) {
            push ( @{$href},${$html_r}[$ix-1] )     if (match($line, $inst_r));
            $ix++;
        }# foreach
        printf "\n";
        return $href;
}#sub   get_references


sub     get_attribute   {
        my  (   $href   )   = @_;
        my $attr_r = [];
        my $n =  subroutine('name');                # identify sub by name
        printf  "\n%5s%s() \n",'',$n if( debug($n));
        foreach my $instance ( @{$href} ) {
            printf  "%10s%s",'',$instance if( debug($n));        # href
            if ( $instance =~ /.*"(.*)">/ ) {
                printf " %s\n", $1 if( debug($n));
                push ( @{$attr_r}, $1);
            } else {
                printf "\n" if( debug($n));
            }#if match
        }#for all
        return $attr_r;
}#sub   get_attribute


sub     get_filepath    {
        my  (   $att_r  
            ,   $apath   )   = @_;
        my $path_r = [];
        my $n =  subroutine('name');                # identify sub by name
        printf  "\n%5s%s() \n",'',$n if( debug($n));
        foreach my $attribute ( @{$att_r} ) {
            my  $inst_r = [];
            if ( $attribute =~ m/^(.*)[.]htm[?]f=(\d+)&s=(\d+)/ ) {
                my ($path, $rec) = ( $1.$2.'.json', $3 );
                printf "%9s%s %s",'',$1,$2;
                printf "\t%s\trecord %s",  $path, $rec;
                my $fpath = $apath.$path;
                printf "\tfile exists\n", if ( -e $fpath );
                printf "\tfile doesn't exists\n", if ( ! -e $fpath );
                push ( @{$inst_r}, ($fpath,$rec) );
            }
            push ( @{$path_r}, $inst_r);
        }#for all attributes
        return $path_r;
}#sub   get_filepath


sub     get_record  {
        my  (   $path_r )   = @_;                   # reference to json files
        my $n =  subroutine('name');                # identify sub by name
        printf  "\n%5s%s() \n",'',$n if( debug($n));
        my $file = ${$path_r}[0][0];
        my $znum = ${$path_r}[0][1];
        printf  "%9s%s\n",'',$file;
        my @json    =   read_utf8   ( $file );
        my $record  =   get_zrecord ( $znum , @json );
        return $record;
}#sub   get_record


sub     get_zrecord    {
        my  (   $znum
            ,   @json   )   = @_;
        my $n =  subroutine('name');                # identify sub by name
        my $record  =   [];
        my $begin   =   $FALSE;
        printf  "\n%5s%s() \n",'',$n if( debug($n));
        printf  "%9s%s%s\n",'','znumber ', $znum;
        printf  "%9s%s %s\n",'','length of json',$#json;
        for my $index   (0 .. $#json) {
            $begin  = $TRUE     if ( $json[$index] =~ m/z$znum/ );   
            push (@{$record}, $json[$index] ) if ( $begin );
            $begin  = $FALSE    if ( $json[$index] =~ m/^},/);
        }# for all lines
        return $record;
}#sub   get_zrecord


sub     get_zdata   {
        my  (   $scope
            ,   $zrecord_r  )   = @_;
        my $n =  subroutine('name');                # identify sub by name
        my $sep = ',';                              # Separator
        printf  "\n%5s%s() \n"  ,'',$n if( debug($n));
        printf  "%9s%s%s\n"     ,'','Scope ', $scope;
        printf  "%9s%s %s\n"    ,'','Record Length ',$#{$zrecord_r};
        my  $zdata      =   {};
        $$zdata{scope}  =   $scope;
        $$zdata{data}   =   [];
        foreach my $line ( @{$zrecord_r} ) {
            chomp ( $line );
            if ( $line =~ m/$scope/ ) {
                printf  "%9s%s\n",'',$line;
                slice_data  ( $sep , $line );
            }#if
        }#foreach line
}#sub   get_zdata


sub     slice_data  {
        my  (   $separator
            ,   $line       )   = @_;
        my $n =  subroutine('name');                # identify sub by name
        printf  "\n%5s%s() \n"  ,'',$n; # if( debug($n));
        my @data = split ( $separator, $line );
        foreach my $info ( @data ) {
                printf  "%9s%s\n",'',$info;
        }#foreach
}#sub   slice_data

### sub     get_record_old {
###         my  (   $path_r )   = @_;                   # reference to json files
###         my $n =  subroutine('name');                # identify sub by name
###         printf  "\n%5s%s() \n",'',$n if( debug($n));
###         my $file = ${$path_r}[0][0];
###         my $znum = ${$path_r}[0][1];
###         #foreach my $inst_r  ( @{$path_r} ) {
###         #   my $file    =   $inst_r->[0];
###         #   my $znum    =   $inst_r->[1];
###             printf  "%9s%s\n",'',$file;
###             my @json    =   read_utf8   ( $file );
###             my $record  =   get_zrecord ( $znum , @json );
###         #}#
### }#sub   get_record_old
### 
### 
### sub     get_zrecord_old    {
###         my  (   $znum
###             ,   @json   )   = @_;
###         my $n =  subroutine('name');                # identify sub by name
###         printf  "\n%5s%s() \n",'',$n if( debug($n));
###         printf  "%9s%s%s\n",'','znumber ', $znum;
###         my $tmp = join ("",@json);                  # compact string, multiline string
###         my $cut;
###         printf "%5s%s %s\n",'','length of json',length $tmp;
###         #if  ( $tmp =~   m/},\n(z$znum:{.*?}),\n(z\d+):{prod:'/xms ) {
###         if  ( $tmp =~   m/},\n(z$znum:{.*?}),\n(z\d+):{prod:'/xms ) {
###             $cut = $1;
###             printf "\n\n%s\n"   ,'>'x25;
###             printf "\n\n\n%s\n" , $cut;
###         }else{
###             printf "\n\n%s\n",'>'x25;
###         }
###         return $cut;
### }#sub   get_zrecord_old

#----------------------------------------------------------------------------
#  P R I V A T E  M E T H O D S

sub     maxwidth    {
        my  (   $array_r    )   =   @_;
        my  $max    =   0;
        foreach my $entry  ( @{$array_r} ) {
            my $tmp =   length($entry);
            $max = ( $max > $tmp ) ? $max : $tmp;
        }#for all
        return $max;
}#sub   maxwidth


sub     unique  {
        my  (   $array_r    )   =   @_;
        my  %seen;
        my  $unique = [];
        foreach my $entry   ( @{$array_r} ) {
            push ( @{$unique}, $entry ) if ( !$seen{$entry}++ );
        }
        return $unique;
}#sub   unique


sub     match    {                                  # $string match @array
        my  (   $line
            ,   $inst_r )   = @_;
        my $found = 0;
        foreach my $instance    ( @{$inst_r} ) {
            next        if $line !~ m/$instance/ ; 
            $found++    if $line =~ m/$instance/ ;
        }# 
        return $found;
}#sub   match 

#----------------------------------------------------------------------------
#  End of module
1;
