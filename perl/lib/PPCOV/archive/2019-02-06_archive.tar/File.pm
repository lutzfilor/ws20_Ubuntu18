package File;
# File          File.pm
#
# Refactored    01/25/2019          
# Author        Lutz Filor
# 
# Synopsys      File::filename_generator() creates unique 
#                                          derivative
#               
#               XML::preserve_space() restoring XML string, 
#               encode record separator properly
#
#               XML::split 

use strict;
use warnings;

use Readonly;
use POSIX qw(strftime);

use lib             qw  (   ../lib );               # Relative UserModulePath
use Dbg             qw  (   debug subroutine    );
use UTF8            qw  (   read_utf8   write_utf8  );

#----------------------------------------------------------------------------
# I N T E R F A C E

use version; our $VERSION =version->declare("v1.01.01");

use Exporter qw (import);
use parent 'Exporter';                              # parent replaces base

our @EXPORT     = qw(    
                    );   #implicite export          # NOT recommended to use

our @EXPORT_OK  = qw(   filename_generator                      
                    );   #explicite export          # RECOMMENDED

our %EXPORT_TAGS=   ( ALL => [ @EXPORT_OK ]
                    );

#----------------------------------------------------------------------------
# C O N S T A N T S

#----------------------------------------------------------------------------
# S U B R O U T I N S

sub     filename_generator  {
        my  (   $opts_ref   )   =   @_;
        my  $fullname           =   ${$opts_ref}{workbook};
        my  (   $na,$pa,$su )   =   fileparse( $fullname, qr{[.][^.]*} );
        my  $i = ${$opts_ref}{indent};              # indentation
        my  $p = ${$opts_ref}{indent_pattern};      # indentation pattern
        
        printf  "%*s%s %s\n",'Source Name',$fullname;
        
}#sub   filename_generator

